using System.Data.Entity;

namespace PHISHING.Models.Context
{
    public class WEBContext : DbContext
    {
        public WEBContext() : base("PDB")
        { }
        public virtual IDbSet<Admin> Admins { get; set; }
        public virtual IDbSet<Category> Categories { get; set; }
        public virtual IDbSet<Interaction> Interactions { get; set; }
        public virtual IDbSet<Page> Pages { get; set; }
        public virtual IDbSet<PhishingEmail> PhishingEmails { get; set; }
        public virtual IDbSet<Recipient> Recipients { get; set; }
        public virtual IDbSet<Template> Templates { get; set; }
        public virtual IDbSet<Type> Types{ get; set; }

    }
}   