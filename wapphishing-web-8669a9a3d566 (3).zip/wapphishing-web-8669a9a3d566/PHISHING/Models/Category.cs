using System.ComponentModel.DataAnnotations;

namespace PHISHING.Models
{
    public class Category
    {
        [Key]
        public int CategoryID { get; set; }
        
        [Display(Name = "CategoryName")]
        [Required]
        [StringLength(400, ErrorMessage = "Character limit exceeded!!")]
        public string CategoryName { get; set; }

    }
}