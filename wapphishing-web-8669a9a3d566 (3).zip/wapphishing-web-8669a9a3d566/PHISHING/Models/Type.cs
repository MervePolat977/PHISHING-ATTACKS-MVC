
namespace PHISHING.Models
{
    using System.ComponentModel.DataAnnotations;

    public class Type
    {
        [Key]   
        public int TypeID { get; set; }
        

        [Display(Name = "TypeName")]
        [Required]
        [StringLength(400, ErrorMessage = "Character limit exceeded!!")]
        public string TypeName { get; set; }
        // It shows which scenario affecting on victims
    }
}