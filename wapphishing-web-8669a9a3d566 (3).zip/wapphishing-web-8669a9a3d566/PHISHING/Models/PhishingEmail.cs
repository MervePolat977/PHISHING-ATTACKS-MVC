using System.ComponentModel.DataAnnotations;

namespace PHISHING.Models
{
    public class PhishingEmail
    {
        [Key]
        public int EmailID { get; set; }
        
        [Display(Name = "Content")]
        [Required]
        [StringLength(4000, ErrorMessage = "Character limit exceeded!!")]
        public string Content { get; set; }

        [Display(Name = "Content")]
        [Required]
        [StringLength(400, ErrorMessage = "Character limit exceeded!!")]
        public string Title { get; set; }

        public int AdminID { get; set; }
        
        [Required]
        public int TemplateID { get; set; }
        
        [Required]
        public int CategoryID { get; set; }

        [Required]
        public int RecipientID { get; set; }
        
        public virtual Admin Admin { get; set; }
        public virtual Template Template { get; set; }
        public virtual Recipient Recipient { get; set; }
        public virtual Category Category { get; set; }
    }
}