
namespace PHISHING.Models
{
    using System.ComponentModel.DataAnnotations;

    public class Template
    {
        [Key]
        public int TemplateID { get; set; }
        
        [Display(Name = "TemplateName")]
        [Required]
        [StringLength(400, ErrorMessage = "Character limit exceeded!!")]
        public string TemplateName { get; set; }
    }
}