using System.ComponentModel.DataAnnotations;

namespace PHISHING.Models
{
    public class Admin
    {
        [Key]
        public int AdminID { get; set; }
        
        [Display(Name = "AdminFullName")]
        [Required]
        [StringLength(400, ErrorMessage = "Character limit exceeded!!")]
        public string AdminFullName { get; set; }
        
        [Display(Name = "AdminEmail")]
        [Required]
        [StringLength(400, ErrorMessage = "Character limit exceeded!!")]
        public string AdminEmail { get; set; }
        
        [Display(Name = "Password")]
        [Required]
        [StringLength(400, ErrorMessage = "Character limit exceeded!!")]
        public string Password { get; set; }
    }
}