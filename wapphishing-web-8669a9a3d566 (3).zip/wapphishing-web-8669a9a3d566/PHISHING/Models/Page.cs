using System.ComponentModel.DataAnnotations;

namespace PHISHING.Models
{
    public class Page
    {
        [Key]   
        public int PageID { get; set; }
        
        [Display(Name = "CategoryID")]
        [Required]
        [StringLength(400, ErrorMessage = "Character limit exceeded!!")]
        public string CategoryID { get; set; }
        
        [Display(Name = "URL")]
        [Required]
        [StringLength(400, ErrorMessage = "Character limit exceeded!!")]
        public string URL { get; set; }
        
        public virtual Category Category { get; set; }
    }
}