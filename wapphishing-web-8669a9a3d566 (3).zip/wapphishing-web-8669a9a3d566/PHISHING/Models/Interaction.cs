using System.ComponentModel.DataAnnotations;

namespace PHISHING.Models
{
    public class Interaction
    {
        [Key]   
        public int InteractionID { get; set; }
        
        [Required]
        [Display(Name ="IsClicked")]
        public bool IsClicked { get; set; }
        
        [Required]
        public int PageID { get; set; }
        [Required]
        public int AdminID { get; set; }
        [Required]
        public int RecipientID { get; set; }
    
        public virtual Page Page { get; set; }
        public virtual Admin Admin { get; set; }
        public virtual Recipient Recipient { get; set; }

    }
}