using System.ComponentModel.DataAnnotations;

namespace PHISHING.Models
{
    public  class Recipient
    {
        [Key]   
        public int RecipientID { get; set; }
        
        // No need to add an extra email information because its already exist
        [Display(Name = "RecipientEmail")]
        [Required]
        [StringLength(400, ErrorMessage = "Character limit exceeded!!")]
        public string RecipientEmail { get; set; }
        
        [Display(Name = "Username")]
        [StringLength(400, ErrorMessage = "Character limit exceeded!!")]
        public string Username { get; set; }


        [Display(Name = "Phone")]
        [StringLength(400, ErrorMessage = "Character limit exceeded!!")]
        public string Phone { get; set; }
        

        [Display(Name = "Password")]
        [StringLength(400, ErrorMessage = "Character limit exceeded!!")]
        public string Password { get; set; }
        [Required]
        public int TypeID { get; set; }
         
        public virtual Type Type { get; set; }
    }
}