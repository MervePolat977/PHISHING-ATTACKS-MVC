﻿
namespace PHISHING.Controllers
{
    using PHISHING.Models;
    using PHISHING.Models.Dto_s;
    using System.Linq;
    using System.Web.Mvc;
    using System.Web.Security;

    public class AuthController : Controller
    {
        // GET: Auth
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(AdminToLogin adminToLogin)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (var db = new PHISHING.Models.Context.WEBContext())
                    {

                        var admin = db.Set<Admin>().FirstOrDefault(i => i.AdminEmail == adminToLogin.Email);
                        
                        if (admin != null)
                        {
                            FormsAuthentication.SetAuthCookie(admin.AdminEmail, false);

                            Session["Mail"] = admin.AdminEmail.ToString();
                            Session["FullName"] = admin.AdminFullName.ToString();
                            return RedirectToAction("Index", "Admin");

                        }
                        return View();
                    }
                }
                return View();
            }
            catch (System.Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View();
            }
        }
        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(AdminToRegister adminToRegister)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (var db = new Models.Context.WEBContext())
                    {
                        var admin = new Admin
                        {
                            AdminEmail = adminToRegister.Email,
                            AdminFullName = adminToRegister.FullName,
                            Password = adminToRegister.Password,

                        };
                        db.Set<Admin>().Add(admin);
                        db.SaveChanges();
                        
                        FormsAuthentication.SetAuthCookie(admin.AdminEmail, false);

                        Session["Mail"] = admin.AdminEmail.ToString();
                        Session["FullName"] = admin.AdminFullName.ToString();
                        return RedirectToAction("Index" , "Admin");
                    }
                }
                return View();
            }
            catch (System.Exception ex)
            {
                ModelState.AddModelError("",ex.Message);
                return View();

            }

        }

    }
}