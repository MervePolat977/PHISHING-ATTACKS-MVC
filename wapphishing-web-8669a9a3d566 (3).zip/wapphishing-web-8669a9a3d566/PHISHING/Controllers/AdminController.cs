﻿

namespace PHISHING.Controllers
{
    using PagedList;
    using PHISHING.Models;
    using PHISHING.Models.Context;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Mail;
    using System.Web.Mvc;

    [Authorize]
    public class AdminController : Controller
    {
        // GET: Admin


        public ActionResult Index(int pageNumber = 1, int pageSize = 8)
        {
            using (var db = new WEBContext())
            {
                var result = db.Set<Recipient>().ToList();
                return View(result.ToPagedList(pageNumber, pageSize));
            }
        }

        public ActionResult Categories(int pageNumber = 1, int pageSize = 8)
        {
            using (var db = new WEBContext())
            {
                var result = db.Set<Category>().ToList();
                return View(result.ToPagedList(pageNumber, pageSize));
            }
        }
        public ActionResult Emails(int pageNumber = 1, int pageSize = 8)
        {
            using (var db = new WEBContext())
            {
                var result = db.Set<PhishingEmail>().ToList();
                return View(result.ToPagedList(pageNumber, pageSize));
            }
        }
        [HttpGet]
        public ActionResult EmailSender()
        {
            using (var db = new WEBContext())
            {
                List<SelectListItem> recipients = (from i in db.Set<Recipient>().ToList()
                                                   select new SelectListItem
                                                   {
                                                       Value = i.RecipientID.ToString(),
                                                       Text = i.RecipientEmail
                                                   }).ToList();
                List<SelectListItem> categories = (from i in db.Set<Category>().ToList()
                                                   select new SelectListItem
                                                   {
                                                       Value = i.CategoryID.ToString(),
                                                       Text = i.CategoryName
                                                   }).ToList();
                List<SelectListItem> templates = (from i in db.Set<Template>().ToList()
                                                   select new SelectListItem
                                                   {
                                                       Value = i.TemplateID.ToString(),
                                                       Text = i.TemplateName
                                                   }).ToList();
                ViewBag.recipients = recipients;
                ViewBag.categories = categories;
                ViewBag.templates = templates;
            }
            return View();
        }
        [HttpPost]
        public ActionResult EmailSender(PhishingEmail email)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (var db = new WEBContext())
                    {
                        email.AdminID = db.Set<Admin>().FirstOrDefault(s => s.AdminEmail == User.Identity.Name).AdminID;
                        email.Admin = db.Set<Admin>().FirstOrDefault(s => s.AdminEmail == User.Identity.Name);

                        db.Set<PhishingEmail>().Add(email);
                        db.SaveChanges();
                        var smtpClient = new SmtpClient(email.Admin.AdminEmail)
                        {
                            Port = 587,
                            Credentials = new NetworkCredential(email.Admin.AdminEmail , email.Admin.Password),
                            EnableSsl = true
                        };
                        var mailMessage = new MailMessage(email.Admin.AdminEmail , email.Recipient.RecipientEmail,email.Title , email.Content);
                        smtpClient.SendMailAsync(mailMessage);
                        
                    }
                    return View();
                }
                return View();
            }
            catch (System.Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View();
            }
            
        }


    }
}