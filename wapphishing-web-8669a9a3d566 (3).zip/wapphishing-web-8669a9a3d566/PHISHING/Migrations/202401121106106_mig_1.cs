﻿namespace PHISHING.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class mig_1 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Admins",
                c => new
                    {
                        AdminID = c.Int(nullable: false, identity: true),
                        AdminFullName = c.String(nullable: false, maxLength: 400),
                        AdminEmail = c.String(nullable: false, maxLength: 400),
                        Password = c.String(nullable: false, maxLength: 400),
                    })
                .PrimaryKey(t => t.AdminID);
            
            CreateTable(
                "dbo.Categories",
                c => new
                    {
                        CategoryID = c.Int(nullable: false, identity: true),
                        CategoryName = c.String(nullable: false, maxLength: 400),
                    })
                .PrimaryKey(t => t.CategoryID);
            
            CreateTable(
                "dbo.Interactions",
                c => new
                    {
                        InteractionID = c.Int(nullable: false, identity: true),
                        IsClicked = c.Boolean(nullable: false),
                        PageID = c.Int(nullable: false),
                        AdminID = c.Int(nullable: false),
                        RecipientID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.InteractionID)
                .ForeignKey("dbo.Admins", t => t.AdminID, cascadeDelete: true)
                .ForeignKey("dbo.Pages", t => t.PageID, cascadeDelete: true)
                .ForeignKey("dbo.Recipients", t => t.RecipientID, cascadeDelete: true)
                .Index(t => t.PageID)
                .Index(t => t.AdminID)
                .Index(t => t.RecipientID);
            
            CreateTable(
                "dbo.Pages",
                c => new
                    {
                        PageID = c.Int(nullable: false, identity: true),
                        CategoryID = c.String(nullable: false, maxLength: 400),
                        URL = c.String(nullable: false, maxLength: 400),
                        Category_CategoryID = c.Int(),
                    })
                .PrimaryKey(t => t.PageID)
                .ForeignKey("dbo.Categories", t => t.Category_CategoryID)
                .Index(t => t.Category_CategoryID);
            
            CreateTable(
                "dbo.Recipients",
                c => new
                    {
                        RecipientID = c.Int(nullable: false, identity: true),
                        RecipientEmail = c.String(nullable: false, maxLength: 400),
                    })
                .PrimaryKey(t => t.RecipientID);
            
            CreateTable(
                "dbo.PhishingEmails",
                c => new
                    {
                        EmailID = c.Int(nullable: false, identity: true),
                        Content = c.String(nullable: false, maxLength: 400),
                        AdminID = c.Int(nullable: false),
                        TemplateID = c.Int(nullable: false),
                        CategoryID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.EmailID)
                .ForeignKey("dbo.Admins", t => t.AdminID, cascadeDelete: true)
                .ForeignKey("dbo.Categories", t => t.CategoryID, cascadeDelete: true)
                .ForeignKey("dbo.Templates", t => t.TemplateID, cascadeDelete: true)
                .Index(t => t.AdminID)
                .Index(t => t.TemplateID)
                .Index(t => t.CategoryID);
            
            CreateTable(
                "dbo.Templates",
                c => new
                    {
                        TemplateID = c.Int(nullable: false, identity: true),
                        TemplateName = c.String(nullable: false, maxLength: 400),
                    })
                .PrimaryKey(t => t.TemplateID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.PhishingEmails", "TemplateID", "dbo.Templates");
            DropForeignKey("dbo.PhishingEmails", "CategoryID", "dbo.Categories");
            DropForeignKey("dbo.PhishingEmails", "AdminID", "dbo.Admins");
            DropForeignKey("dbo.Interactions", "RecipientID", "dbo.Recipients");
            DropForeignKey("dbo.Interactions", "PageID", "dbo.Pages");
            DropForeignKey("dbo.Pages", "Category_CategoryID", "dbo.Categories");
            DropForeignKey("dbo.Interactions", "AdminID", "dbo.Admins");
            DropIndex("dbo.PhishingEmails", new[] { "CategoryID" });
            DropIndex("dbo.PhishingEmails", new[] { "TemplateID" });
            DropIndex("dbo.PhishingEmails", new[] { "AdminID" });
            DropIndex("dbo.Pages", new[] { "Category_CategoryID" });
            DropIndex("dbo.Interactions", new[] { "RecipientID" });
            DropIndex("dbo.Interactions", new[] { "AdminID" });
            DropIndex("dbo.Interactions", new[] { "PageID" });
            DropTable("dbo.Templates");
            DropTable("dbo.PhishingEmails");
            DropTable("dbo.Recipients");
            DropTable("dbo.Pages");
            DropTable("dbo.Interactions");
            DropTable("dbo.Categories");
            DropTable("dbo.Admins");
        }
    }
}
